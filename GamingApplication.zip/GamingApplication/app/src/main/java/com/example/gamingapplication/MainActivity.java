package com.example.gamingapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.the_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageView img = (ImageView) findViewById(R.id.imageView);
                img.clearAnimation();
                TranslateAnimation translation;
                translation = new TranslateAnimation(0f, 0f, 0f, 600f);
                translation.setDuration(2000);
                translation.setFillAfter(true);
                translation.setInterpolator(new BounceInterpolator());
                img.startAnimation(translation);
            }
        });

    }
}